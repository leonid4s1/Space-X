
/**
 *
 * @author LEONARDO
 */
import edu.epromero.util.StdRandom;
import edu.epromero.util.LienzoStd;

public class BaseN extends Graficos {

    public BaseN() {
        setSprite(".//src//asteroide.jpg");
        inicia();
    }

    public void inicia() {
        super.inicia();
        setColumna(StdRandom.uniforme(LienzoStd.pideLimiteXMin() + (LienzoStd.pideLimiteXMax() / 2), LienzoStd.pideLimiteXMax()));
        setRenglon(StdRandom.uniforme(LienzoStd.pideLimiteYMin(), LienzoStd.pideLimiteYMax() / 3));
        dibSprite.ponColorTransparente(LienzoStd.BLANCO);

    }

    public boolean HayColision(Entrada e) {
        boolean hayColision = false;

        if (e.getAlien().getComponenteY() == Graficos.ABAJO) {
            if (e.getAlien().getColumna() <= getColumna() + dibSprite.ancho() / 2 && e.getAlien().getColumna() >= getColumna() - dibSprite.ancho() / 2) {
                if (e.getAlien().getRenglon() <= getRenglon() + dibSprite.alto() * 2 && e.getAlien().getRenglon() >= getRenglon() - dibSprite.alto() * 2) {
                    hayColision = true;
                }
            }
        }
        return hayColision;
    }

    void Mueve(Entrada e) {

    }
}

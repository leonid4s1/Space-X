
import edu.epromero.util.LienzoStd;
import static java.awt.event.KeyEvent.VK_LEFT;
import static java.awt.event.KeyEvent.VK_RIGHT;

/**
 *
 * @author LEONARDO
 */
public class Juego {

    private Marciano alien;
    private BaseN asteroide;
    private BaseN2 asteroide2;
    private BaseN3 asteroide3;
    private Graficos elemento[];
    private Entrada e;

    Juego() {
        alien = new Marciano();
        asteroide = new BaseN();
        asteroide2 = new BaseN2();
        asteroide3 = new BaseN3();
        inicia();
        e = new Entrada();
    }

    public void Mueve() {
        int tecla = 0;
        if (LienzoStd.fuePulsadaTecla(VK_RIGHT)) {
            tecla = Graficos.DERECHA;
        } else if (LienzoStd.fuePulsadaTecla(VK_LEFT)) {
            tecla = Graficos.IZQUIERDA;
        }
        e.setAlien(alien);
        e.setTecla(tecla);

        for (int i = 0; i < elemento.length; i++) {
            elemento[i].Mueve(e);
        }

        if (getAsteroide().HayColision(e)) {
            alien.Rebota();
        }
        if (asteroide2.HayColision(e)) {
            alien.Rebota();
        }
        if (asteroide3.HayColision(e)) {
            alien.Rebota();
        }

    }

    public void Pinta() {
        for (int i = 0; i < elemento.length; i++) {
            elemento[i].pinta();
        }
    }

    public void Borra() {
        LienzoStd.limpia();
    }

    public void inicia() {
        LienzoStd.ponTamanioLienzo(600, 900);
        LienzoStd.ponEscalaX(0, 600);
        LienzoStd.ponEscalaY(0, 900);
        alien.inicia();
        getAsteroide().inicia();
        asteroide2.inicia();
        asteroide3.inicia();
        elemento = new Graficos[4];
        elemento[0] = alien;
        elemento[1] = getAsteroide();
        elemento[2] = asteroide2;
        elemento[3] = asteroide3;
    }

    /**
     * @return the asteroide
     */
    public BaseN getAsteroide() {
        return asteroide;
    }

}

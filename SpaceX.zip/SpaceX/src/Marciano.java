
import edu.epromero.util.LienzoStd;

/**
 *
 * @author LEONARDO
 */
public class Marciano extends Graficos {

    private double componenteX;
    private double componenteY;

    public Marciano() {
        setSprite(".//src//marciano.jpg");
        setComponenteX(ARRIBA);
        setComponenteY(ABAJO);
    }

    public Marciano(double col, double ren) {
        setColumna(col);
        setRenglon(ren);
        setSprite(".//src//marciano.jpg");
    }

    public void inicia() {
        super.inicia();
        dibSprite.ponColorTransparente(LienzoStd.BLANCO);
        setColumna(LienzoStd.pideLimiteXMax());
        setRenglon(LienzoStd.pideLimiteYMax());
    }

    void Mueve(Entrada e) {
        if (e.getTecla() == DERECHA) {
            if (columna + 15 < LienzoStd.pideLimiteXMax()) {
                columna = columna + 15;
            } else {
                columna = LienzoStd.pideLimiteXMin() - 15;
            }
        }
        if (e.getTecla() == IZQUIERDA) {
            if (columna - 15 > LienzoStd.pideLimiteXMin()) {
                columna = columna - 15;
            } else {
                columna = LienzoStd.pideLimiteXMax() - 15;
            }
        }
        if (renglon > (LienzoStd.pideLimiteYMax()*2)/ 3) {
            setComponenteY(ABAJO);
        }
        renglon = renglon + componenteY * 20;
    }

    void Rebota() {
        setComponenteY(ARRIBA);
    }

    public double getComponenteX() {
        return componenteX;
    }

    public void setComponenteX(double componenteX) {
        this.componenteX = componenteX;
    }

    public double getComponenteY() {
        return componenteY;
    }

    public void setComponenteY(double componenteY) {
        this.componenteY = componenteY;
    }

}


import edu.epromero.util.LienzoStd;
import edu.epromero.util.StdRandom;

/**
 *
 * @author LEONARDO
 */
public class BaseN2 extends BaseN {

    public BaseN2() {
        setSprite(".//src//asteroide.jpg");
        inicia();
    }

    public void inicia() {
        super.inicia();
        setColumna(StdRandom.uniforme(LienzoStd.pideLimiteXMin(), LienzoStd.pideLimiteXMax()/2));
        setRenglon(StdRandom.uniforme(LienzoStd.pideLimiteYMin() / 3, (LienzoStd.pideLimiteYMax() * 2) / 3));
        dibSprite.ponColorTransparente(LienzoStd.BLANCO);
    }

}


import edu.epromero.util.LienzoStd;
import edu.epromero.util.StdRandom;

/**
 *
 * @author LEONARDO
 */
public class BaseN3 extends BaseN {

    public BaseN3() {
        setSprite(".//src//asteroide.jpg");
        inicia();
    }

    public void inicia() {
        super.inicia();
        setColumna(StdRandom.uniforme(LienzoStd.pideLimiteXMin(), LienzoStd.pideLimiteXMax()));
        setRenglon(StdRandom.uniforme(LienzoStd.pideLimiteYMin(), LienzoStd.pideLimiteYMax()));
        dibSprite.ponColorTransparente(LienzoStd.BLANCO);
    }
}


/**
 *
 * @author LEONARDO
 */
import edu.epromero.util.LienzoStd;
import edu.epromero.util.StdOut;
import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SpaceX {

    static Juego partida;

    public static void main(String[] args) {
        partida = new Juego();

        try {
            while (true) {
                partida.Mueve();
                partida.Pinta();

                LienzoStd.mostrar(0);
                sleep(50);
                LienzoStd.mostrar(0);
                partida.Borra();
            }
        } catch (InterruptedException ex) {
            StdOut.print("No se durmio");
            Logger.getLogger(SpaceX.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}

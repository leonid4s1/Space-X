
/**
 *
 * @author LEONARDO
 */
public class Entrada {

    private int tecla;
    private Marciano alien;

    public int getTecla() {
        return tecla;
    }

    public void setTecla(int tecla) {
        this.tecla = tecla;
    }

    public Marciano getAlien() {
        return alien;
    }

    public void setAlien(Marciano alien) {
        this.alien = alien;
    }

}

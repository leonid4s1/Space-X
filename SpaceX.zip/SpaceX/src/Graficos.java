
/**
 *
 * @author LEONARDO
 */
import edu.epromero.util.Imagen;
import edu.epromero.util.LienzoStd;

public abstract class Graficos {

    protected double columna;
    protected double renglon;
    protected String sprite;
    protected Imagen dibSprite;

    public static final int DERECHA = 1;
    public static final int IZQUIERDA = -1;
    public static final int ARRIBA = 1;
    public static final int ABAJO = -1;

    public Graficos() {
        setColumna(0);
        setRenglon(0);
        setSprite("");
    }

    public Graficos(double col, double ren) {
        setColumna(col);
        setRenglon(ren);
        setSprite("");
    }

    abstract void Mueve(Entrada e);

    public void pinta() {
        LienzoStd.dibujo(getColumna(), getRenglon(), dibSprite);
    }

    public void inicia() {
        dibSprite = new Imagen(sprite);
    }

    public double getColumna() {
        return columna;
    }

    public void setColumna(double columna) {
        this.columna = columna;
    }

    public double getRenglon() {
        return renglon;
    }

    public void setRenglon(double renglon) {
        this.renglon = renglon;
    }

    public String getSprite() {
        return sprite;
    }

    public void setSprite(String sprite) {
        this.sprite = sprite;
    }

    public Imagen getDibSprite() {
        return dibSprite;
    }

    public void setDibSprite(Imagen dibSprite) {
        this.dibSprite = dibSprite;
    }

}
